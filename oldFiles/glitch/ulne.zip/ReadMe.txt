This flash is a combination of No1b4me's UL4S & NEWD codes and is to be used only for communicating to a Dish card.

The following INS commands are supported in this flash:

INS01:          Reset Card
INS02:          Shut down card
INS0E:          Set I/O Watchdog timer
INS1x:          Set communication params
INS8x - INSBx:  Block Rx
INSCx - INSFx:  Block Tx
  

The following commands are supported in this flash:

80:             Check for card present
90:             Send 4 Byte Chip ID (ULNE)
Ax:             Set LED...  x = 0(off), 1(red) or 2(green)


All glitching commands have been disabled in this flash.

Note: This code will not get you free tv or help you to break the cards security.
 